﻿$(document).ready(function () {
    'use strict';

    console.log("here");
    const dialogflow = require(["dialogflow"]);
    
    const dfMessenger = document.querySelector("df-messenger");
    //dfMessenger.showMinChat();
    

    //dfMessenger.addEventListener("click", function (event) {
    //    console.log("I've been clicked");
    //});

    //dfMessenger.addEventListener("df-request-sent", function (event) {
    //    console.log("sent");
    //});
    console.log("done");
});