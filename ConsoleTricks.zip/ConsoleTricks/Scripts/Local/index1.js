﻿document.addEventListener("DOMContentLoaded", () => {

    document.getElementById("btnNotifications").addEventListener("click", function () {
        var value = parseInt($('#lblIncrement').text());
        var newValue = value + 1;
        $('#lblIncrement').text(newValue);
    });
    
    document.getElementById("btnGetNotificationCount").addEventListener("click", function () {
        var value = parseInt($('#lblIncrement').text());
        kendoConsole.log("Notification count " + value);
    });

});
